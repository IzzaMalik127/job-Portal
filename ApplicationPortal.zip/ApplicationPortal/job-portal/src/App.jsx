import { useState } from "react";
import { Modal, Button, ProgressBar } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

export default function App() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    cnic: "",
    education: "",
    skills: [],
    role: "",
    cv: null,
  });

  const [errors, setErrors] = useState({});
  const [showModal, setShowModal] = useState(false);

  // Progress bar calculation
  const totalFields = 7;
  const filledFields = Object.entries(formData).filter(([key, val]) => {
    if (Array.isArray(val)) return val.length > 0;
    return val !== "" && val !== null;
  }).length;
  const progress = Math.floor((filledFields / totalFields) * 100);

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({ ...formData, [name]: files[0] });
    } else if (type === "checkbox") {
      let updatedSkills = [...formData.skills];
      if (e.target.checked) {
        updatedSkills.push(value);
      } else {
        updatedSkills = updatedSkills.filter((skill) => skill !== value);
      }
      setFormData({ ...formData, skills: updatedSkills });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const validate = () => {
    let newErrors = {};
    if (!formData.fullName.trim()) newErrors.fullName = "Full Name is required.";
    if (!formData.email.match(/^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/))
      newErrors.email = "Valid Email is required.";
    if (!formData.phone.match(/^[0-9]{11}$/))
      newErrors.phone = "Phone number must be 11 digits.";
    if (!formData.cnic.match(/^[0-9]{13}$/))
      newErrors.cnic = "CNIC must be 13 digits.";
    if (!formData.education) newErrors.education = "Education is required.";
    if (formData.skills.length === 0) newErrors.skills = "Select at least one skill.";
    if (!formData.role) newErrors.role = "Preferred role is required.";
    if (!formData.cv) newErrors.cv = "Please upload your CV.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log(formData);
      setShowModal(true);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Mini Job Application Portal</h2>

      {/* Progress Bar */}
      <ProgressBar now={progress} label={`${progress}%`} className="mb-3" />

      <form onSubmit={handleSubmit}>
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">Full Name</label>
            <input
              type="text"
              className={`form-control ${errors.fullName ? "is-invalid" : ""}`}
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
            />
            <div className="invalid-feedback">{errors.fullName}</div>
          </div>
          <div className="col-md-6">
            <label className="form-label">Email</label>
            <input
              type="email"
              className={`form-control ${errors.email ? "is-invalid" : ""}`}
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
            <div className="invalid-feedback">{errors.email}</div>
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">Phone Number</label>
            <input
              type="text"
              className={`form-control ${errors.phone ? "is-invalid" : ""}`}
              name="phone"
              value={formData.phone}
              onChange={handleChange}
            />
            <div className="invalid-feedback">{errors.phone}</div>
          </div>
          <div className="col-md-6">
            <label className="form-label">CNIC</label>
            <input
              type="text"
              className={`form-control ${errors.cnic ? "is-invalid" : ""}`}
              name="cnic"
              value={formData.cnic}
              onChange={handleChange}
            />
            <div className="invalid-feedback">{errors.cnic}</div>
          </div>
        </div>

        <div className="mb-3">
          <label className="form-label">Education Level</label>
          <select
            className={`form-select ${errors.education ? "is-invalid" : ""}`}
            name="education"
            value={formData.education}
            onChange={handleChange}
          >
            <option value="">Select</option>
            <option value="Matric">Matric</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Bachelor">Bachelor</option>
            <option value="Master">Master</option>
          </select>
          <div className="invalid-feedback">{errors.education}</div>
        </div>

        <div className="mb-3">
          <label className="form-label">Skills</label>
          <div className="d-flex flex-wrap gap-3">
            {["HTML", "CSS", "JavaScript", "React", "Bootstrap"].map((skill) => (
              <div key={skill} className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  value={skill}
                  onChange={handleChange}
                  checked={formData.skills.includes(skill)}
                />
                <label className="form-check-label">{skill}</label>
              </div>
            ))}
          </div>
          {errors.skills && <div className="text-danger mt-1">{errors.skills}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Preferred Role</label>
          <select
            className={`form-select ${errors.role ? "is-invalid" : ""}`}
            name="role"
            value={formData.role}
            onChange={handleChange}
          >
            <option value="">Select</option>
            <option value="Frontend Developer">Frontend Developer</option>
            <option value="Backend Developer">Backend Developer</option>
            <option value="Full Stack Developer">Full Stack Developer</option>
          </select>
          <div className="invalid-feedback">{errors.role}</div>
        </div>

        <div className="mb-3">
          <label className="form-label">Upload CV</label>
          <input
            type="file"
            className={`form-control ${errors.cv ? "is-invalid" : ""}`}
            name="cv"
            onChange={handleChange}
          />
          <div className="invalid-feedback">{errors.cv}</div>
        </div>

        <button type="submit" className="btn btn-primary w-100">
          Submit Application
        </button>
      </form>

      {/* Summary Modal */}
      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Application Summary</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p><strong>Name:</strong> {formData.fullName}</p>
          <p><strong>Email:</strong> {formData.email}</p>
          <p><strong>Phone:</strong> {formData.phone}</p>
          <p><strong>CNIC:</strong> {formData.cnic}</p>
          <p><strong>Education:</strong> {formData.education}</p>
          <p><strong>Skills:</strong> {formData.skills.join(", ")}</p>
          <p><strong>Role:</strong> {formData.role}</p>
          <p><strong>CV:</strong> {formData.cv?.name}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

